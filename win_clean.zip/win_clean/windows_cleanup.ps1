﻿# 윈도우 정리 스크립트 시작
# 관리자 권한 확인
# --- 관리자 자동 상승 (헤더에 넣으세요) ---
# 사용법: 그냥 스크립트 맨 위에 붙여넣으면 됩니다.
# KEEP_OPEN 환경변수(옵션): KEEP_OPEN=1 로 설정하면 관리자 창에서 -NoExit 로 실행되어 창이 닫히지 않습니다.

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) {

    # 관리자 재실행용 인자 구성
    $baseArgs = @('-NoProfile','-ExecutionPolicy','Bypass','-File', $MyInvocation.MyCommand.Path)

    # KEEP_OPEN 환경변수(있으면 NoExit 유지)
    if ($env:KEEP_OPEN -eq '1') {
        # -NoExit 는 파워셸 자체 인자여서 앞에 두지 않음, Start-Process로 다시 띄울 때 최종 파워셸 인자에 포함
        $baseArgs = @('-NoProfile','-ExecutionPolicy','Bypass','-NoExit','-File', $MyInvocation.MyCommand.Path)
    }

    # $args (스크립트에 전달된 인자들)을 안전하게 추가
    if ($args.Count -gt 0) {
        $baseArgs += $args
    }

    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $baseArgs
    exit
}
# --- 여기까지 관리자 자동 상승 블록 ---

Clear-Host
Write-Host "=====================================================" -ForegroundColor Cyan # 시작 헤더 색상
Write-Host "         Windows 정리 스크립트 (범용성 강화)" -ForegroundColor Cyan # 시작 헤더 색상
Write-Host "=====================================================" -ForegroundColor Cyan # 시작 헤더 색상
Write-Host # 빈 줄

$ErrorActionPreference = "SilentlyContinue"

# 사용자 입력 함수 (색상 추가)
function Get-UserConfirmation {
    param(
        [string]$PromptMessage,
        [string]$DefaultAnswer = "N" # Y or N
    )
    while ($true) {
        Write-Host ""
        # 프롬프트 메시지를 먼저 출력하고 줄바꿈 안함 (색상 적용)
        Write-Host "$PromptMessage (Y/N)" -ForegroundColor Green -NoNewline
        $input = Read-Host # Read-Host는 이제 단순히 사용자 입력만 받음

        if ($input -eq "") { $input = $DefaultAnswer } # Enter 키 입력 시 기본값 사용
        if ($input -match "^[Yy]$") { return $true }
        elseif ($input -match "^[Nn]$") { return $false }
        else { Write-Host "잘못된 입력입니다. 'Y' 또는 'N'을 입력해주세요." -ForegroundColor Yellow } # 잘못된 입력 경고 색상
    }
}

# 예상 용량 계산 함수
function Get-SizeSumMB($paths) {
    $total = 0
    foreach ($pathEntry in $paths) {
        $path = if ($pathEntry -is [string]) { $pathEntry } else { $pathEntry.Path }
        if (Test-Path $path) {
            Try {
                # ReparsePoint(심볼릭 링크 등) 제외하여 무한 루프 방지 및 정확한 크기 계산
                $items = Get-ChildItem -Path $path -Recurse -ErrorAction SilentlyContinue | Where-Object { -not ($_.Attributes -band [System.IO.FileAttributes]::ReparsePoint) }
                $size = ($items | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum
                $total += $size
            }
            Catch {
                # 경로 접근 권한 오류 등은 무시하고 계속 진행
            }
        }
    }
    return [math]::Round($total / 1MB, 2)
}

# 로딩 스피너 함수 (ASCII 문자 사용)
function Show-Spinner {
    param([string]$Message)
    $i = 0
    $spinner = "|/-\\"
    $script:Spinning = $true
    while ($script:Spinning) {
        Write-Host "`r$Message $($spinner[$i++ % $spinner.Length])" -NoNewline -ForegroundColor DarkGray # 스피너 색상
        Start-Sleep -Milliseconds 100
    }
    $clearLineLength = $Message.Length + $spinner.Length + 10
    $clearLine = "`r" + (" " * $clearLineLength)
    Write-Host $clearLine
}

# 대상 폴더 목록 (표시 및 크기 계산용) - [ordered] 유지하여 순서 보장
$targetsForDisplay = [ordered]@{
    "Windows 업데이트 캐시"     = "$env:SystemRoot\SoftwareDistribution\Download"
    "WinSxS (DISM 정리)"        = "시스템 구성 요소 저장소"
    "Windows.old 폴더"          = "C:\Windows.old (존재 시 사용자 확인)"
    "DirectX 셰이더 캐시"       = "C:\ProgramData\Microsoft\Windows\D3DSCache 등"
    "사용자 임시 파일"          = "$env:TEMP"
    "시스템 임시 파일"          = "C:\Windows\Temp"
    "프리페치 파일"             = "$env:SystemRoot\Prefetch"
    "휴지통"                    = "모든 사용자의 휴지통"
    "전달 최적화 파일"          = "$env:SystemRoot\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache"
    "Windows 오류 보고(WER) 파일" = "C:\ProgramData\Microsoft\Windows\WER"
    "USOPrivate 업데이트 저장소" = "C:\ProgramData\USOPrivate\UpdateStore"
    "Defender 보호 기록"        = "Windows Defender 검사 기록"
    "DNS 캐시 초기화"           = "DNS 캐시" # DNS 캐시 초기화는 파일 삭제가 아니지만, 여기에 포함하여 표시
    "이벤트 로그"               = "C:\Windows\System32\winevt\Logs (일부 시스템 로그 제외 시도)"
    "메모리 덤프 파일"          = "C:\Windows\Minidump 및 MEMORY.DMP"
    "썸네일 캐시"               = "$env:LocalAppData\Microsoft\Windows\Explorer (thumbcache_*.db)"
    "글꼴 캐시"                 = "$env:LocalAppData\Microsoft\FontCache"
    "아이콘 캐시"               = "$env:LocalAppData\Microsoft\Windows\Explorer"
    "Edge 브라우저 캐시"       = "$env:LocalAppData\Microsoft\Edge\User Data\Default"
    "Whale 브라우저 캐시"      = "$env:LocalAppData\Naver\Naver Whale\User Data\Default"
    "Chrome 브라우저 캐시"     = "$env:LocalAppData\Google\Chrome\User Data\Default"
    "Microsoft Store 캐시"     = "$env:LocalAppData\Packages\Microsoft.WindowsStore_*\LocalCache"
    "기타 브라우저 캐시"        = "Firefox, Opera, Vivaldi, Waterfox 등"
}

Write-Host "다음 항목에 대해 정리 작업을 진행합니다:" -ForegroundColor White
$itemCounter = 1
foreach ($name in $targetsForDisplay.Keys) {
    Write-Host ("  * {0,2}. {1}" -f $itemCounter, $name) -ForegroundColor Gray # 항목 목록 색상
    $itemCounter++
}
Write-Host # 빈 줄

# 실제 크기 계산 대상 경로 - [ordered] 유지하여 순서 보장
$targetsForCalc = [ordered]@{
    "Windows 업데이트 캐시" = "$env:SystemRoot\SoftwareDistribution\Download"
    "사용자 임시 파일" = "$env:TEMP"
    "시스템 임시 파일" = "C:\Windows\Temp"
    "프리페치 파일" = "$env:SystemRoot\Prefetch"
    "Store 캐시" = "$env:LocalAppData\Packages\Microsoft.WindowsStore_*\LocalCache"
    "Edge 브라우저 캐시" = "$env:LocalAppData\Microsoft\Edge\User Data\Default\Cache"
    "Whale 브라우저 캐시" = "$env:LocalAppData\Naver\Naver Whale\User Data\Default\Cache"
    "Chrome 브라우저 캐시" = "$env:LocalAppData\Google\Chrome\User Data\Default\Cache"
    "썸네일 캐시" = "$env:LocalAppData\Microsoft\Windows\Explorer"
    "전달 최적화 파일" = "$env:SystemRoot\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache"
    "WER 파일" = "C:\ProgramData\Microsoft\Windows\WER"
    "USOPrivate UpdateStore" = "C:\ProgramData\USOPrivate\UpdateStore"
    "메모리 덤프" = @("$env:SystemRoot\Minidump", "$env:SystemRoot\MEMORY.DMP")
    "DirectX 셰이더 캐시" = @("C:\ProgramData\Microsoft\Windows\D3DSCache", "$env:LocalAppData\D3DSCache")
    "글꼴 캐시" = "$env:LocalAppData\Microsoft\FontCache"
    "아이콘 캐시" = "$env:LocalAppData\Microsoft\Windows\Explorer"
}

# --- 예상 확보 용량 계산 시작 ---
Write-Host "예상 확보 용량 계산 중..." -ForegroundColor DarkYellow
$script:Spinning = $true
$spinnerJob = Start-Job -ScriptBlock { Show-Spinner -Message "용량 계산 중..." }
Start-Sleep -Milliseconds 100 # 스피너 시작 대기

$totalSize = 0
foreach ($name in $targetsForCalc.Keys) {
    $pathOrPaths = $targetsForCalc[$name]
    if ($name -eq "썸네일 캐시") {
        $size = Get-SizeSumMB @(Get-ChildItem -Path $pathOrPaths -Filter "thumbcache_*.db" -Recurse -ErrorAction SilentlyContinue | Select-Object -ExpandProperty FullName)
    } elseif ($pathOrPaths -is [array]) {
        $size = Get-SizeSumMB $pathOrPaths
    } else {
        $size = Get-SizeSumMB @($pathOrPaths)
    }
    $totalSize += $size
}
if (Test-Path "$env:SystemDrive\Windows.old") {
    $totalSize += Get-SizeSumMB @("$env:SystemDrive\Windows.old")
}

$script:Spinning = $false # 스피너 중지
Wait-Job $spinnerJob | Out-Null
Remove-Job $spinnerJob | Out-Null

Write-Host # 빈 줄을 하나 출력하여 다음 메시지와 간격을 둡니다.

$totalSizeFormatted = if ($totalSize -ge 1024) { "$([math]::Floor($totalSize / 1024)) GB $([math]::Round($totalSize % 1024, 2)) MB" } else { "$([math]::Round($totalSize, 2)) MB" }
# 강조된 용량 부분만 Yellow로 표시
Write-Host "계산된 총 예상 확보 용량: " -NoNewline -ForegroundColor White
Write-Host "$totalSizeFormatted" -NoNewline -ForegroundColor Yellow # 용량 값만 Yellow
Write-Host " (실제 정리 후 다를 수 있음)" -ForegroundColor White
Write-Host # 빈 줄

# --- 사용자 확인 ---
$confirmStart = Get-UserConfirmation -PromptMessage "위 항목들에 대한 정리 작업을 시작하시겠습니까?"
if (-not $confirmStart) {
    Write-Host "작업이 취소되었습니다." -ForegroundColor Yellow
    Start-Sleep -Seconds 3
    exit
}
Write-Host "정리 작업을 시작합니다..." -ForegroundColor Green
Start-Sleep -Seconds 1

# --- 정리 작업 정의 ---
$cleanupActions = @(
    @{ Name = "Windows 업데이트 캐시"; Action = { Try { Stop-Service wuauserv -Force -ErrorAction SilentlyContinue; Stop-Service bits -Force -ErrorAction SilentlyContinue; Remove-Item "$($env:SystemRoot)\SoftwareDistribution\Download\*" -Recurse -Force -ErrorAction SilentlyContinue; Start-Service wuauserv -ErrorAction SilentlyContinue; Start-Service bits -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "WinSxS 정리 (DISM)"; Action = {
        Write-Host "  시스템 구성 요소 정리 중... (시간이 다소 소요될 수 있습니다)" -NoNewline -ForegroundColor DarkYellow
        # Start-Job으로 스피너를 백그라운드에서 실행
        $script:Spinning = $true
        $spinnerJob = Start-Job -ScriptBlock { param($Message) Show-Spinner -Message $Message } -ArgumentList "  DISM 정리 중..."
        Start-Sleep -Milliseconds 100 # 스피너 시작 대기

        Try {
            # DISM 명령 실행 (여기서 시간이 오래 걸림)
            $dismOutput = dism.exe /online /Cleanup-Image /StartComponentCleanup /ResetBase 4>&1 # 에러 스트림도 함께 캡처
            if ($LASTEXITCODE -ne 0) {
                # DISM 명령이 0이 아닌 종료 코드를 반환하면 오류로 간주
                Write-Host "`r  오류: DISM 작업 실패. 자세한 내용은 위 로그를 확인하세요." -ForegroundColor Red
            } else {
                Write-Host "`r  완료                   " -ForegroundColor Green
            }
        } Catch {
            Write-Host "`r  오류: PowerShell 오류 발생: $($_.Exception.Message.Split('.')[0])              " -ForegroundColor Red
        }
        finally {
            $script:Spinning = false # 스피너 중지 플래그
            Wait-Job $spinnerJob | Out-Null # 스피너 작업 완료 대기
            Remove-Job $spinnerJob | Out-Null # 스피너 작업 제거
        }
    } },
    @{ Name = "Windows.old 폴더 삭제"; Condition = { Test-Path "$($env:SystemDrive)\Windows.old" }; Action = {
        Write-Host ""
        $confirmOld = Get-UserConfirmation -PromptMessage " 'Windows.old' 폴더가 존재합니다. 삭제하시겠습니까? (이전 Windows로 복구 불가)"
        if ($confirmOld) {
            Try { Remove-Item "$($env:SystemDrive)\Windows.old" -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "  'Windows.old' 폴더 삭제 완료." -ForegroundColor Green }
            Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red }
        } else {
            Write-Host "  'Windows.old' 폴더 삭제를 건너뛰었습니다." -ForegroundColor Yellow
        }
    } },
    @{ Name = "DirectX 셰이더 캐시 삭제"; Action = { Try { Remove-Item "C:\ProgramData\Microsoft\Windows\D3DSCache\*" -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item "$env:LocalAppData\D3DSCache\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "임시 파일 정리"; Action = { Try { Remove-Item "$($env:TEMP)\*" -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item "C:\Windows\Temp\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "프리페치 파일 정리"; Action = { Try { Remove-Item "$($env:SystemRoot)\Prefetch\*" -Force -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "휴지통 비우기"; Action = { Try { Clear-RecycleBin -Force -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "전달 최적화 파일 삭제"; Action = { Try { Remove-Item "$($env:SystemRoot)\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "Windows 오류 보고(WER) 삭제"; Action = { Try { Remove-Item "C:\ProgramData\Microsoft\Windows\WER\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "USOPrivate 업데이트 저장소 삭제"; Action = { Try { Remove-Item "C:\ProgramData\USOPrivate\UpdateStore\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "Defender 보호 기록 삭제"; Action = { Try { if (Get-Module -ListAvailable -Name "Defender") { Import-Module Defender -Force -ErrorAction SilentlyContinue; Remove-MpThreat -All -ErrorAction SilentlyContinue }; Remove-Item "C:\ProgramData\Microsoft\Windows Defender\Scans\History\Service\DetectionHistory\*" -Force -Recurse -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "DNS 캐시 초기화"; Action = { Try { ipconfig /flushdns | Out-Null; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "이벤트 로그 삭제"; Action = { Try { Get-ChildItem "C:\Windows\System32\winevt\Logs\*.evtx" -Recurse -Force | ForEach-Object { if ($_.Name -notmatch "^System.evtx$|^Application.evtx$|^Security.evtx$") { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue } }; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "메모리 덤프 파일 삭제"; Action = { Try { Remove-Item "$($env:SystemRoot)\Minidump\*" -Recurse -Force -ErrorAction SilentlyContinue; Remove-Item "$($env:SystemRoot)\MEMORY.DMP" -Force -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "썸네일 캐시 삭제"; Action = {
        Try {
            # explorer.exe 종료/시작 로직을 제거하여 깜빡임 방지.
            # 이로 인해 캐시 파일이 사용 중일 수 있어 완전히 삭제되지 않을 수 있습니다.
            # 완벽한 정리는 재부팅 시에 이루어집니다.
            Get-ChildItem "$($env:LocalAppData)\Microsoft\Windows\Explorer\thumbcache_*.db" -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue;
            Write-Host "  완료 (일부 파일은 사용 중일 수 있음)" -ForegroundColor Green
        } Catch {
            Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red
        }
    } },
    @{ Name = "글꼴 캐시 삭제"; Action = { Try { Stop-Service FontCache -ErrorAction SilentlyContinue; Remove-Item "$env:LocalAppData\Microsoft\FontCache\*" -Recurse -Force -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "아이콘 캐시 삭제"; Action = {
        Try {
            # explorer.exe 종료/시작 로직을 제거하여 깜빡임 방지.
            # 이로 인해 캐시 파일이 사용 중일 수 있어 완전히 삭제되지 않을 수 있습니다.
            # 완벽한 정리는 재부팅 시에 이루어집니다.
            Get-ChildItem "$env:LocalAppData\Microsoft\Windows\Explorer\IconCache*" -Force -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue;
            Write-Host "  완료 (일부 파일은 사용 중일 수 있음)" -ForegroundColor Green
        } Catch {
            Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red
        }
    } },
    @{ Name = "Edge 브라우저 캐시 삭제"; Action = { Try { @("Cache", "Code Cache", "GPUCache", "Media Cache") | ForEach-Object { Remove-Item "$($env:LocalAppData)\Microsoft\Edge\User Data\Default\$_*" -Recurse -Force -ErrorAction SilentlyContinue }; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "Whale 브라우저 캐시 삭제"; Action = { Try { @("Cache", "Code Cache", "GPUCache", "Media Cache") | ForEach-Object { Remove-Item "$($env:LocalAppData)\Naver\Naver Whale\User Data\Default\$_*" -Recurse -Force -ErrorAction SilentlyContinue }; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "Chrome 브라우저 캐시 삭제"; Action = { Try { @("Cache", "Code Cache", "GPUCache", "Media Cache") | ForEach-Object { Remove-Item "$($env:LocalAppData)\Google\Chrome\User Data\Default\$_*" -Recurse -Force -ErrorAction SilentlyContinue }; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "Microsoft Store 캐시 삭제"; Action = { Try { Get-ChildItem "$($env:LocalAppData)\Packages\Microsoft.WindowsStore_*\LocalCache" -Recurse -Force | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue; Write-Host "  완료" -ForegroundColor Green } Catch { Write-Host "  오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red } } },
    @{ Name = "기타 브라우저 캐시 삭제"; Action = {
        $runningBrowsers = @()
        $browserPaths = @{}

        if (Get-Process -Name "opera" -ErrorAction SilentlyContinue) { $runningBrowsers += "Opera"; $browserPaths["Opera"] = "$($env:AppData)\Opera Software\Opera Stable" }
        if (Get-Process -Name "vivaldi" -ErrorAction SilentlyContinue) { $runningBrowsers += "Vivaldi"; $browserPaths["Vivaldi"] = "$($env:LocalAppData)\Vivaldi\User Data\Default" }

        if (Get-Process -Name "firefox" -ErrorAction SilentlyContinue) { $runningBrowsers += "Firefox" }
        $firefoxProfilesPath = "$env:AppData\Mozilla\Firefox\Profiles"
        if (Test-Path $firefoxProfilesPath) {
            Get-ChildItem $firefoxProfilesPath -Directory | ForEach-Object {
                $browserPaths["Firefox_$($_.Name)"] = $_.FullName
            }
        }
        if (Get-Process -Name "waterfox" -ErrorAction SilentlyContinue) { $runningBrowsers += "Waterfox" }
        $waterfoxProfilesPath = "$env:AppData\Waterfox\Profiles"
        if (Test-Path $waterfoxProfilesPath) {
            Get-ChildItem $waterfoxProfilesPath -Directory | ForEach-Object {
                $browserPaths["Waterfox_$($_.Name)"] = $_.FullName
            }
        }

        if ($runningBrowsers.Count -gt 0) {
            Write-Host "`n 다음 브라우저가 실행 중입니다: $($runningBrowsers -join ', '). 캐시를 완전히 삭제하려면 종료해야 합니다." -ForegroundColor Yellow
            $confirmBrowser = Get-UserConfirmation -PromptMessage "그래도 진행하시겠습니까?"
            if (-not $confirmBrowser) { Write-Host "  브라우저 캐시 삭제를 건너뛰었습니다." -ForegroundColor Yellow; return }
        }

        foreach ($bKey in $browserPaths.Keys) {
            $bPath = $browserPaths[$bKey]
            $bName = $bKey.Split('_')[0]
            # Write-Host "    - $bName 캐시 정리 중... ($bPath)" -NoNewline -ForegroundColor DarkCyan # Write-Progress에 표시되므로 중복될 수 있음
            Try {
                if ($bName -eq "Firefox" -or $bName -eq "Waterfox") {
                    Get-ChildItem "$bPath\cache2" -Recurse -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
                } else {
                    @("Cache", "Code Cache", "GPUCache", "Media Cache") | ForEach-Object {
                        Remove-Item "$bPath\$_*" -Recurse -Force -ErrorAction SilentlyContinue
                    }
                }
                Write-Host "`r    - $bName 캐시 정리 완료.  " -ForegroundColor Green
            } Catch {
                Write-Host "`r    - $bName 캐시: 오류: $($_.Exception.Message.Split('.')[0])" -ForegroundColor Red
            }
        }
        Write-Host "  완료" -ForegroundColor Green # 기타 브라우저 캐시 전체 완료 메시지
    } }
)

# --- 정리 작업 실행 루프 ---
$totalTasksToPerform = $cleanupActions.Count
$currentTaskNumber = 0

foreach ($task in $cleanupActions) {
    $currentTaskNumber++
    $percentComplete = [math]::Round(($currentTaskNumber / $totalTasksToPerform) * 100)

    # Write-Progress cmdlet 사용
    Write-Progress -Id 0 -Activity "Windows 정리 작업 진행 중" -Status "$($task.Name) 처리 중..." -CurrentOperation "시작 중..." -PercentComplete $percentComplete

    # 각 작업 시작을 명확히 표시
    Write-Host "`n- $($task.Name) " -NoNewline -ForegroundColor White # 작업 이름 강조

    if ($task.Condition -ne $null -and -not (& $task.Condition)) {
        Write-Host " 건너뜁니다 (조건 불충족)." -ForegroundColor Yellow
        Write-Progress -Id 0 -Activity "Windows 정리 작업 진행 중" -Status "$($task.Name)" -CurrentOperation "건너뜀" -PercentComplete $percentComplete
        Start-Sleep -Milliseconds 50
        continue
    }

    & $task.Action

    # 작업 완료 후 Write-Progress 업데이트
    Write-Progress -Id 0 -Activity "Windows 정리 작업 진행 중" -Status "$($task.Name)" -CurrentOperation "완료됨" -PercentComplete $percentComplete
    Start-Sleep -Milliseconds 50
}

# 최종 완료 메시지
Write-Progress -Id 0 -Activity "Windows 정리 작업" -Status "모든 작업 완료됨" -CurrentOperation "모든 정리 완료!" -PercentComplete 100 -Completed:$true

Write-Host "`n모든 정리 작업이 완료되었습니다!" -ForegroundColor Green # 최종 완료 메시지 강조

# --- 재부팅 권장 메시지 추가 ---
Write-Host "`n일부 정리된 캐시(예: 글꼴, 아이콘)를 완전히 적용하려면 컴퓨터를 재부팅하는 것이 좋습니다." -ForegroundColor Yellow
Write-Host "지금 바로 재부팅하시겠습니까? (Y/N)" -ForegroundColor Yellow
$rebootConfirm = Read-Host

if ($rebootConfirm -match "^[Yy]$") {
    Write-Host "컴퓨터를 재부팅합니다..." -ForegroundColor Cyan
    shutdown /r /t 0
} else {
    Write-Host "재부팅을 건너뛰었습니다. 원하실 때 수동으로 재부팅해주세요." -ForegroundColor Yellow
    Start-Sleep -Seconds 3 # 이 메시지 표시를 위한 잠시 대기 후 스크립트 종료
}