--------------------------------------------------------------------

1. Install the program.
2. Use Keygen, Generate a License key to register the application.
3. Enjoy.

--------------------------------------------------------------------
