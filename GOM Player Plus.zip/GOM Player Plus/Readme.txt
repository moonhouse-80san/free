--------------------------------------------------------------------

1. Install the program. Don't start!
2. Copy Patch file to program installation directory.
3. Run Patch file as Administrator and apply it.
4. Enjoy!

--------------------------------------------------------------------
