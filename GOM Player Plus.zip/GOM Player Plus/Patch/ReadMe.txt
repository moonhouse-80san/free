***************************************
1- Please copy the patcher to the GOM Player Plus installation directory
and run it there. Otherwise, patching cannot be done.

2- Apply Patch & Enjoy !
***************************************

Note: The patcher with No-Buttons has the same features as the regular patcher,
but the only difference between the two is:
The patcher with No-Buttons does the patching and also makes the "Register,
Remote and Support" buttons invisible.







***************************************
///yaschir///
***************************************



